// Itay Zahor 208127480

import biuoop.DrawSurface;
import java.awt.Color;

/**
 * The game winner animation.
 *
 * @author Itay Zahor
 */
public class YouWinAnimation implements Animation {
    private final Counter score;
    private final boolean stop;
    /**
     * Instantiates a new winner animation.
     *
     * @param score the ending score
     */
    public YouWinAnimation(Counter score) {
        this.score = score;
        this.stop = false;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        d.setColor(Color.black);
        d.drawText(10, d.getHeight() / 2,
                "You Win! Your score is " + this.score.getValue(), 32);
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}

