// Itay Zahor 208127480

import biuoop.DrawSurface;
import java.awt.Color;

/**
 * The type Game over animation.
 *
 * @author Itay Zahor
 */
public class GameOverAnimation implements Animation {
    private final Counter score;
    private final boolean stop;

    /**
     * Instantiates a new Game over animation.
     *
     * @param score    the score
     */
    public GameOverAnimation(Counter score) {
        this.score = score;
        this.stop = false;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        // Draw the game over message and score
        d.setColor(Color.BLACK);
        d.drawText(10, d.getHeight() / 2, "Game Over. Your score is "
                + this.score.getValue(), 32);
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
